/**
 ******************************************************************************
 * @file           : main.c
 * @author         : Juan Pablo Toro Arenas
 * @brief          : Desarrollo del driver para el USART
 ******************************************************************************
 * - Implementación de las liberías CMSIS
 * - Migración del GPIO driver
 * - Desarrollo de las librerías para el manejo del USART
 ******************************************************************************
 */


#include <stm32f4xx.h>
#include <stdint.h>
#include "GPIOxDriver.h"
#include "USARTxDriver.h"
#include "BasicTimer.h"

/* Variables del proyecto */

GPIO_Handler_t handlerLedOk = {0};
BTIMER_Handler_t handlerTimerEjemplo = {0};

// *************** // Headers // *************** //

void delay(int time);
void initSystem

int main(void)
{





	//Cargamos la configuración
	USART_Config(&handlerLedOk);
	GPIO_Config(&handlerTimerEjemplo);

    /* Ciclo principal */
	while(1){

	}
}

//***********// Definición de Funciones //***********//

void delay(int time){
	// Con este ciclo se genera un intervalo de tiempo en el programa (no tiene otro objetivo)
	for (int i = 0; i <= time; i++){
		__NOP();
	}
}

void BTimer_Callback(void){
	handlerLedOk.pGPIOx -> ODR ^= GPIO_ODR_OD9;
}
